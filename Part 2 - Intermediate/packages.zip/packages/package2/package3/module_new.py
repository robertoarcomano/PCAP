def new_function():
    print("new_function")
